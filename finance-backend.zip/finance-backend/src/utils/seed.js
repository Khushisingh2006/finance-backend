require('dotenv').config();
const { sequelize, User, Transaction } = require('../models');

const seed = async () => {
  await sequelize.sync({ force: true });
  console.log('Database synced.');

  // Create users
  const admin = await User.create({
    name: 'Admin User',
    email: 'admin@finance.com',
    password: 'admin123',
    role: 'admin',
    status: 'active',
  });

  const analyst = await User.create({
    name: 'Analyst User',
    email: 'analyst@finance.com',
    password: 'analyst123',
    role: 'analyst',
    status: 'active',
  });

  await User.create({
    name: 'Viewer User',
    email: 'viewer@finance.com',
    password: 'viewer123',
    role: 'viewer',
    status: 'active',
  });

  console.log('Users created.');

  // Seed transactions
  const categories = {
    income: ['Salary', 'Freelance', 'Investment', 'Bonus', 'Rental Income'],
    expense: ['Rent', 'Utilities', 'Food', 'Transport', 'Marketing', 'Software', 'Salaries'],
  };

  const transactions = [];
  const now = new Date();

  for (let i = 0; i < 60; i++) {
    const type = Math.random() > 0.45 ? 'expense' : 'income';
    const catList = categories[type];
    const category = catList[Math.floor(Math.random() * catList.length)];
    const monthOffset = Math.floor(i / 10);
    const d = new Date(now.getFullYear(), now.getMonth() - monthOffset, Math.floor(Math.random() * 28) + 1);
    transactions.push({
      amount: parseFloat((Math.random() * 9000 + 100).toFixed(2)),
      type,
      category,
      date: d.toISOString().slice(0, 10),
      notes: `${category} transaction for ${d.toLocaleString('default', { month: 'long' })}`,
      createdBy: Math.random() > 0.5 ? admin.id : analyst.id,
    });
  }

  await Transaction.bulkCreate(transactions);
  console.log('60 transactions seeded.');
  console.log('\n--- Login Credentials ---');
  console.log('Admin:   admin@finance.com   / admin123');
  console.log('Analyst: analyst@finance.com / analyst123');
  console.log('Viewer:  viewer@finance.com  / viewer123');
  process.exit(0);
};

seed().catch((err) => {
  console.error('Seed failed:', err);
  process.exit(1);
});
