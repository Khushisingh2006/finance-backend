const express = require('express');
const router = express.Router();
const txController = require('../controllers/transactionController');
const { authenticate, authorize } = require('../middleware/auth');
const { transactionValidators, validate } = require('../middleware/validators');

// All routes require authentication
router.use(authenticate);

// Viewers and above can read
router.get('/', transactionValidators.filters, validate, txController.getAll);
router.get('/:id', txController.getOne);

// Only admin and analyst can create/update/delete
router.post('/', authorize('admin', 'analyst'), transactionValidators.create, validate, txController.create);
router.put('/:id', authorize('admin', 'analyst'), transactionValidators.update, validate, txController.update);
router.delete('/:id', authorize('admin'), txController.remove);

module.exports = router;
