const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');
const { authenticate, authorize } = require('../middleware/auth');
const { userValidators, validate } = require('../middleware/validators');

router.use(authenticate);

// Admin only: manage users
router.get('/', authorize('admin'), userController.getAll);
router.get('/:id', authorize('admin'), userController.getOne);
router.patch('/:id/role', authorize('admin'), userValidators.updateRole, validate, userController.updateRole);
router.patch('/:id/status', authorize('admin'), userValidators.updateStatus, validate, userController.updateStatus);
router.delete('/:id', authorize('admin'), userController.deleteUser);

module.exports = router;
