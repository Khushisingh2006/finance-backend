const express = require('express');
const router = express.Router();
const dashboardController = require('../controllers/dashboardController');
const { authenticate, authorize } = require('../middleware/auth');

// All dashboard routes: analyst and admin only
router.use(authenticate, authorize('admin', 'analyst'));

router.get('/summary', dashboardController.getSummary);
router.get('/categories', dashboardController.getCategoryTotals);
router.get('/trends', dashboardController.getMonthlyTrends);
router.get('/recent', dashboardController.getRecentActivity);

module.exports = router;
