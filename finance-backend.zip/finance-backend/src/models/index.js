const sequelize = require('../config/database');
const User = require('./User');
const Transaction = require('./Transaction');

// Associations
Transaction.belongsTo(User, { foreignKey: 'createdBy', as: 'creator' });
User.hasMany(Transaction, { foreignKey: 'createdBy', as: 'transactions' });

module.exports = { sequelize, User, Transaction };
