const { body, query, param, validationResult } = require('express-validator');

const validate = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      success: false,
      message: 'Validation failed.',
      errors: errors.array().map((e) => ({ field: e.path, message: e.msg })),
    });
  }
  next();
};

const authValidators = {
  register: [
    body('name').trim().notEmpty().withMessage('Name is required.').isLength({ min: 2, max: 100 }),
    body('email').isEmail().withMessage('Valid email is required.').normalizeEmail(),
    body('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters.'),
    body('role').optional().isIn(['admin', 'analyst', 'viewer']).withMessage('Invalid role.'),
  ],
  login: [
    body('email').isEmail().withMessage('Valid email is required.').normalizeEmail(),
    body('password').notEmpty().withMessage('Password is required.'),
  ],
};

const transactionValidators = {
  create: [
    body('amount').isFloat({ min: 0.01 }).withMessage('Amount must be a positive number.'),
    body('type').isIn(['income', 'expense']).withMessage('Type must be income or expense.'),
    body('category').trim().notEmpty().withMessage('Category is required.'),
    body('date').isDate().withMessage('Date must be a valid date (YYYY-MM-DD).'),
    body('notes').optional().isString().isLength({ max: 500 }),
  ],
  update: [
    body('amount').optional().isFloat({ min: 0.01 }).withMessage('Amount must be a positive number.'),
    body('type').optional().isIn(['income', 'expense']).withMessage('Type must be income or expense.'),
    body('category').optional().trim().notEmpty().withMessage('Category cannot be empty.'),
    body('date').optional().isDate().withMessage('Date must be a valid date (YYYY-MM-DD).'),
    body('notes').optional().isString().isLength({ max: 500 }),
  ],
  filters: [
    query('type').optional().isIn(['income', 'expense']),
    query('category').optional().isString(),
    query('startDate').optional().isDate(),
    query('endDate').optional().isDate(),
    query('page').optional().isInt({ min: 1 }),
    query('limit').optional().isInt({ min: 1, max: 100 }),
  ],
};

const userValidators = {
  updateRole: [
    body('role').isIn(['admin', 'analyst', 'viewer']).withMessage('Invalid role.'),
  ],
  updateStatus: [
    body('status').isIn(['active', 'inactive']).withMessage('Status must be active or inactive.'),
  ],
};

module.exports = { validate, authValidators, transactionValidators, userValidators };
