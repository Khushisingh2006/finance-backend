const { Op, fn, col, literal } = require('sequelize');
const sequelize = require('../config/database');
const { Transaction } = require('../models');

const getSummary = async () => {
  const [income, expense] = await Promise.all([
    Transaction.unscoped().sum('amount', { where: { type: 'income', deletedAt: null } }),
    Transaction.unscoped().sum('amount', { where: { type: 'expense', deletedAt: null } }),
  ]);

  const totalIncome = parseFloat(income || 0);
  const totalExpense = parseFloat(expense || 0);

  return {
    totalIncome,
    totalExpense,
    netBalance: parseFloat((totalIncome - totalExpense).toFixed(2)),
  };
};

const getCategoryTotals = async () => {
  const rows = await Transaction.unscoped().findAll({
    where: { deletedAt: null },
    attributes: [
      'type',
      'category',
      [fn('SUM', col('amount')), 'total'],
      [fn('COUNT', col('id')), 'count'],
    ],
    group: ['type', 'category'],
    order: [['type', 'ASC'], [literal('total'), 'DESC']],
    raw: true,
  });

  const result = { income: [], expense: [] };
  rows.forEach((row) => {
    result[row.type].push({
      category: row.category,
      total: parseFloat(row.total),
      count: parseInt(row.count),
    });
  });
  return result;
};

const getMonthlyTrends = async (months = 6) => {
  const startDate = new Date();
  startDate.setMonth(startDate.getMonth() - months + 1);
  startDate.setDate(1);

  const rows = await Transaction.unscoped().findAll({
    where: {
      deletedAt: null,
      date: { [Op.gte]: startDate.toISOString().slice(0, 10) },
    },
    attributes: [
      [fn('strftime', '%Y-%m', col('date')), 'month'],
      'type',
      [fn('SUM', col('amount')), 'total'],
    ],
    group: [literal("strftime('%Y-%m', date)"), 'type'],
    order: [[literal("strftime('%Y-%m', date)"), 'ASC']],
    raw: true,
  });

  // Build structured monthly map
  const map = {};
  rows.forEach(({ month, type, total }) => {
    if (!map[month]) map[month] = { month, income: 0, expense: 0 };
    map[month][type] = parseFloat(total);
  });

  return Object.values(map).map((m) => ({
    ...m,
    net: parseFloat((m.income - m.expense).toFixed(2)),
  }));
};

const getRecentActivity = async (limit = 10) => {
  return Transaction.unscoped().findAll({
    where: { deletedAt: null },
    order: [['createdAt', 'DESC']],
    limit,
    raw: true,
  });
};

module.exports = { getSummary, getCategoryTotals, getMonthlyTrends, getRecentActivity };
