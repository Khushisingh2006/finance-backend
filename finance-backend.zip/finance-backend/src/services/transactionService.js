const { Op } = require('sequelize');
const { Transaction, User } = require('../models');

const buildFilters = ({ type, category, startDate, endDate }) => {
  const where = { deletedAt: null };
  if (type) where.type = type;
  if (category) where.category = { [Op.like]: `%${category}%` };
  if (startDate || endDate) {
    where.date = {};
    if (startDate) where.date[Op.gte] = startDate;
    if (endDate) where.date[Op.lte] = endDate;
  }
  return where;
};

const getAllTransactions = async ({ type, category, startDate, endDate, page = 1, limit = 20 }) => {
  const where = buildFilters({ type, category, startDate, endDate });
  const offset = (page - 1) * limit;

  const { count, rows } = await Transaction.unscoped().findAndCountAll({
    where,
    include: [{ model: User, as: 'creator', attributes: ['id', 'name', 'email'] }],
    order: [['date', 'DESC'], ['createdAt', 'DESC']],
    limit: parseInt(limit),
    offset,
  });

  return {
    total: count,
    page: parseInt(page),
    totalPages: Math.ceil(count / limit),
    data: rows,
  };
};

const getTransactionById = async (id) => {
  const tx = await Transaction.unscoped().findOne({
    where: { id, deletedAt: null },
    include: [{ model: User, as: 'creator', attributes: ['id', 'name', 'email'] }],
  });
  if (!tx) {
    const err = new Error('Transaction not found.');
    err.status = 404;
    throw err;
  }
  return tx;
};

const createTransaction = async (data, userId) => {
  return Transaction.create({ ...data, createdBy: userId });
};

const updateTransaction = async (id, data) => {
  const tx = await getTransactionById(id);
  await tx.update(data);
  return tx;
};

const softDeleteTransaction = async (id) => {
  const tx = await getTransactionById(id);
  await tx.update({ deletedAt: new Date() });
  return { message: 'Transaction deleted successfully.' };
};

module.exports = {
  getAllTransactions,
  getTransactionById,
  createTransaction,
  updateTransaction,
  softDeleteTransaction,
};
