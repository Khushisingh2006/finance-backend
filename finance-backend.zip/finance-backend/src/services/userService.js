const { User } = require('../models');

const getAllUsers = async () => {
  const users = await User.findAll({ attributes: { exclude: ['password'] } });
  return users;
};

const getUserById = async (id) => {
  const user = await User.findByPk(id, { attributes: { exclude: ['password'] } });
  if (!user) {
    const err = new Error('User not found.');
    err.status = 404;
    throw err;
  }
  return user;
};

const updateRole = async (id, role, requestingUser) => {
  if (parseInt(id) === requestingUser.id) {
    const err = new Error('You cannot change your own role.');
    err.status = 400;
    throw err;
  }
  const user = await getUserById(id);
  await user.update({ role });
  return user;
};

const updateStatus = async (id, status, requestingUser) => {
  if (parseInt(id) === requestingUser.id) {
    const err = new Error('You cannot deactivate your own account.');
    err.status = 400;
    throw err;
  }
  const user = await getUserById(id);
  await user.update({ status });
  return user;
};

const deleteUser = async (id, requestingUser) => {
  if (parseInt(id) === requestingUser.id) {
    const err = new Error('You cannot delete your own account.');
    err.status = 400;
    throw err;
  }
  const user = await getUserById(id);
  await user.destroy();
  return { message: 'User deleted successfully.' };
};

module.exports = { getAllUsers, getUserById, updateRole, updateStatus, deleteUser };
