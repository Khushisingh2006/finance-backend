const userService = require('../services/userService');

const getAll = async (req, res, next) => {
  try {
    const data = await userService.getAllUsers();
    res.status(200).json({ success: true, data });
  } catch (err) {
    next(err);
  }
};

const getOne = async (req, res, next) => {
  try {
    const data = await userService.getUserById(req.params.id);
    res.status(200).json({ success: true, data });
  } catch (err) {
    next(err);
  }
};

const updateRole = async (req, res, next) => {
  try {
    const data = await userService.updateRole(req.params.id, req.body.role, req.user);
    res.status(200).json({ success: true, message: 'Role updated.', data });
  } catch (err) {
    next(err);
  }
};

const updateStatus = async (req, res, next) => {
  try {
    const data = await userService.updateStatus(req.params.id, req.body.status, req.user);
    res.status(200).json({ success: true, message: 'Status updated.', data });
  } catch (err) {
    next(err);
  }
};

const deleteUser = async (req, res, next) => {
  try {
    const result = await userService.deleteUser(req.params.id, req.user);
    res.status(200).json({ success: true, ...result });
  } catch (err) {
    next(err);
  }
};

module.exports = { getAll, getOne, updateRole, updateStatus, deleteUser };
