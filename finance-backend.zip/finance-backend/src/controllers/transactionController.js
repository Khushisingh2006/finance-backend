const txService = require('../services/transactionService');

const getAll = async (req, res, next) => {
  try {
    const result = await txService.getAllTransactions(req.query);
    res.status(200).json({ success: true, data: result });
  } catch (err) {
    next(err);
  }
};

const getOne = async (req, res, next) => {
  try {
    const tx = await txService.getTransactionById(req.params.id);
    res.status(200).json({ success: true, data: tx });
  } catch (err) {
    next(err);
  }
};

const create = async (req, res, next) => {
  try {
    const tx = await txService.createTransaction(req.body, req.user.id);
    res.status(201).json({ success: true, message: 'Transaction created.', data: tx });
  } catch (err) {
    next(err);
  }
};

const update = async (req, res, next) => {
  try {
    const tx = await txService.updateTransaction(req.params.id, req.body);
    res.status(200).json({ success: true, message: 'Transaction updated.', data: tx });
  } catch (err) {
    next(err);
  }
};

const remove = async (req, res, next) => {
  try {
    const result = await txService.softDeleteTransaction(req.params.id);
    res.status(200).json({ success: true, ...result });
  } catch (err) {
    next(err);
  }
};

module.exports = { getAll, getOne, create, update, remove };
