# Finance Data Processing & Access Control Backend

A RESTful backend API for a finance dashboard system, built with **Node.js**, **Express**, and **SQLite** (via Sequelize ORM). It supports role-based access control, financial record management, and dashboard analytics.

---

## Tech Stack

| Layer        | Choice              | Reason                                          |
|--------------|---------------------|-------------------------------------------------|
| Runtime      | Node.js + Express   | Lightweight, fast, easy to structure cleanly    |
| Database     | SQLite (via Sequelize) | Zero-config, file-based, great for evaluation |
| Auth         | JWT (jsonwebtoken)  | Stateless, scalable, standard                   |
| Validation   | express-validator   | Declarative, chainable, clean error output      |
| Password     | bcryptjs            | Industry-standard hashing                       |
| Rate Limit   | express-rate-limit  | Protection against abuse                        |
| Testing      | Jest + Supertest    | Reliable integration tests                      |

---

## Project Structure

```
finance-backend/
├── src/
│   ├── app.js                  # Entry point, middleware setup, server start
│   ├── config/
│   │   └── database.js         # Sequelize + SQLite connection
│   ├── models/
│   │   ├── index.js            # Model associations
│   │   ├── User.js             # User schema with bcrypt hooks
│   │   └── Transaction.js      # Financial record schema (soft delete)
│   ├── controllers/
│   │   ├── authController.js
│   │   ├── transactionController.js
│   │   ├── dashboardController.js
│   │   └── userController.js
│   ├── services/
│   │   ├── authService.js      # Register/login business logic
│   │   ├── transactionService.js
│   │   ├── dashboardService.js # Analytics and aggregation
│   │   └── userService.js
│   ├── middleware/
│   │   ├── auth.js             # JWT authenticate + authorize(roles)
│   │   ├── validators.js       # Input validation rules
│   │   └── errorHandler.js     # Centralized error handling
│   ├── routes/
│   │   ├── auth.js
│   │   ├── transactions.js
│   │   ├── dashboard.js
│   │   └── users.js
│   └── utils/
│       └── seed.js             # Demo data seeder
├── tests/
│   └── api.test.js
├── .env
├── .gitignore
├── jest.config.json
├── package.json
└── README.md
```

---

## Setup & Run

### Prerequisites
- Node.js v18+
- npm

### Installation

```bash
# 1. Clone the repository
git clone <your-repo-url>
cd finance-backend

# 2. Install dependencies
npm install

# 3. Configure environment
cp .env.example .env
# Edit .env if needed (defaults work out of the box)

# 4. Seed demo data (creates finance.db with 3 users + 60 transactions)
npm run seed

# 5. Start the server
npm start

# Development mode (auto-reload)
npm run dev
```

Server runs at: `http://localhost:3000`

### Demo Credentials (after seeding)

| Role    | Email                  | Password    |
|---------|------------------------|-------------|
| Admin   | admin@finance.com      | admin123    |
| Analyst | analyst@finance.com    | analyst123  |
| Viewer  | viewer@finance.com     | viewer123   |

---

## API Reference

All protected routes require: `Authorization: Bearer <token>`

### Auth

| Method | Endpoint             | Access  | Description          |
|--------|----------------------|---------|----------------------|
| POST   | `/api/auth/register` | Public  | Register new user    |
| POST   | `/api/auth/login`    | Public  | Login, receive JWT   |
| GET    | `/api/auth/me`       | Any     | Get current user     |

**POST /api/auth/register**
```json
{
  "name": "John Doe",
  "email": "john@example.com",
  "password": "secret123",
  "role": "viewer"
}
```

**POST /api/auth/login**
```json
{
  "email": "john@example.com",
  "password": "secret123"
}
```
Response includes `token` — use this as Bearer token for all protected requests.

---

### Transactions

| Method | Endpoint                  | Access           | Description                    |
|--------|---------------------------|------------------|--------------------------------|
| GET    | `/api/transactions`       | All roles        | List with filters + pagination |
| GET    | `/api/transactions/:id`   | All roles        | Get single transaction         |
| POST   | `/api/transactions`       | Admin, Analyst   | Create transaction             |
| PUT    | `/api/transactions/:id`   | Admin, Analyst   | Update transaction             |
| DELETE | `/api/transactions/:id`   | Admin only       | Soft delete transaction        |

**Query Parameters (GET /api/transactions)**
```
?type=income|expense
?category=Salary
?startDate=2024-01-01
?endDate=2024-12-31
?page=1&limit=20
```

**POST /api/transactions body**
```json
{
  "amount": 5000.00,
  "type": "income",
  "category": "Salary",
  "date": "2024-01-15",
  "notes": "Monthly salary"
}
```

---

### Dashboard (Admin + Analyst only)

| Method | Endpoint                    | Description                        |
|--------|-----------------------------|------------------------------------|
| GET    | `/api/dashboard/summary`    | Total income, expense, net balance |
| GET    | `/api/dashboard/categories` | Totals grouped by category         |
| GET    | `/api/dashboard/trends`     | Monthly income/expense trends      |
| GET    | `/api/dashboard/recent`     | Recent transactions                |

**GET /api/dashboard/summary** response:
```json
{
  "success": true,
  "data": {
    "totalIncome": 45000.00,
    "totalExpense": 28500.00,
    "netBalance": 16500.00
  }
}
```

**GET /api/dashboard/trends?months=6** response:
```json
{
  "success": true,
  "data": [
    { "month": "2024-08", "income": 8000, "expense": 4200, "net": 3800 },
    { "month": "2024-09", "income": 9500, "expense": 5100, "net": 4400 }
  ]
}
```

---

### User Management (Admin only)

| Method | Endpoint                    | Description           |
|--------|-----------------------------|-----------------------|
| GET    | `/api/users`                | List all users        |
| GET    | `/api/users/:id`            | Get user by ID        |
| PATCH  | `/api/users/:id/role`       | Change user role      |
| PATCH  | `/api/users/:id/status`     | Activate/deactivate   |
| DELETE | `/api/users/:id`            | Delete user           |

**PATCH /api/users/:id/role**
```json
{ "role": "analyst" }
```

**PATCH /api/users/:id/status**
```json
{ "status": "inactive" }
```

---

## Access Control Matrix

| Action                    | Viewer | Analyst | Admin |
|---------------------------|--------|---------|-------|
| View transactions         | ✅     | ✅      | ✅    |
| Create transaction        | ❌     | ✅      | ✅    |
| Update transaction        | ❌     | ✅      | ✅    |
| Delete transaction        | ❌     | ❌      | ✅    |
| View dashboard summary    | ❌     | ✅      | ✅    |
| View category analytics   | ❌     | ✅      | ✅    |
| View monthly trends       | ❌     | ✅      | ✅    |
| Manage users              | ❌     | ❌      | ✅    |

---

## Error Handling

All errors return a consistent shape:

```json
{
  "success": false,
  "message": "Descriptive error message.",
  "errors": [{ "field": "email", "message": "Valid email is required." }]
}
```

| Status | Meaning                     |
|--------|-----------------------------|
| 400    | Validation / bad input      |
| 401    | Not authenticated           |
| 403    | Forbidden (wrong role)      |
| 404    | Resource not found          |
| 409    | Conflict (e.g. duplicate)   |
| 429    | Rate limit exceeded         |
| 500    | Internal server error       |

---

## Running Tests

```bash
npm test
# With coverage
npm test -- --coverage
```

Tests cover: auth flows, role-based access enforcement, transaction CRUD, input validation, and dashboard access.

---

## Assumptions & Tradeoffs

1. **SQLite over PostgreSQL** — Chosen for zero-setup simplicity. The Sequelize ORM makes switching to PostgreSQL or MySQL a one-line config change.
2. **Soft delete on transactions** — Transactions are never truly removed; a `deletedAt` timestamp is set instead. This preserves audit history, a common finance requirement.
3. **Analysts can create/update but not delete** — This reflects a realistic separation of duties: data entry vs. data governance.
4. **Viewers can see all transactions** — The assignment did not specify data scoping per user, so all authenticated users see all records. This can easily be restricted by adding a `createdBy` filter.
5. **JWT stored client-side** — No server-side session store. Token expiry is 7 days. For production, add refresh token rotation.
6. **Rate limiting** — 100 requests per 15 minutes per IP, applied globally. Can be tightened on auth endpoints specifically.
7. **Password security** — bcrypt with salt rounds of 10. Passwords are never returned in any response.

---

## Optional Enhancements Included

- ✅ JWT Authentication
- ✅ Pagination (`page`, `limit` query params)
- ✅ Filtering by type, category, date range
- ✅ Soft delete with `deletedAt`
- ✅ Rate limiting
- ✅ Integration tests (Jest + Supertest)
- ✅ Seed script with realistic data
