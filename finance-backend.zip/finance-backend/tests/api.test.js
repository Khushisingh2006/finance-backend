const request = require('supertest');
const app = require('../src/app');
const { sequelize } = require('../src/models');

let adminToken, analystToken, viewerToken;

beforeAll(async () => {
  await sequelize.sync({ force: true });

  // Register users
  await request(app).post('/api/auth/register').send({
    name: 'Admin', email: 'admin@test.com', password: 'admin123', role: 'admin',
  });
  await request(app).post('/api/auth/register').send({
    name: 'Analyst', email: 'analyst@test.com', password: 'analyst123', role: 'analyst',
  });
  await request(app).post('/api/auth/register').send({
    name: 'Viewer', email: 'viewer@test.com', password: 'viewer123', role: 'viewer',
  });

  const adminRes = await request(app).post('/api/auth/login').send({ email: 'admin@test.com', password: 'admin123' });
  const analystRes = await request(app).post('/api/auth/login').send({ email: 'analyst@test.com', password: 'analyst123' });
  const viewerRes = await request(app).post('/api/auth/login').send({ email: 'viewer@test.com', password: 'viewer123' });

  adminToken = adminRes.body.data.token;
  analystToken = analystRes.body.data.token;
  viewerToken = viewerRes.body.data.token;
});

afterAll(async () => {
  await sequelize.close();
});

// ── Auth Tests ────────────────────────────────────────────────────────────────
describe('POST /api/auth/register', () => {
  it('should reject duplicate email', async () => {
    const res = await request(app).post('/api/auth/register').send({
      name: 'Admin2', email: 'admin@test.com', password: 'admin123',
    });
    expect(res.status).toBe(409);
    expect(res.body.success).toBe(false);
  });

  it('should reject invalid email', async () => {
    const res = await request(app).post('/api/auth/register').send({
      name: 'Test', email: 'not-an-email', password: '123456',
    });
    expect(res.status).toBe(400);
  });
});

describe('POST /api/auth/login', () => {
  it('should login with valid credentials', async () => {
    const res = await request(app).post('/api/auth/login').send({ email: 'admin@test.com', password: 'admin123' });
    expect(res.status).toBe(200);
    expect(res.body.data).toHaveProperty('token');
  });

  it('should reject wrong password', async () => {
    const res = await request(app).post('/api/auth/login').send({ email: 'admin@test.com', password: 'wrongpass' });
    expect(res.status).toBe(401);
  });
});

// ── Transaction Tests ─────────────────────────────────────────────────────────
describe('Transactions', () => {
  let txId;

  it('admin can create a transaction', async () => {
    const res = await request(app)
      .post('/api/transactions')
      .set('Authorization', `Bearer ${adminToken}`)
      .send({ amount: 5000, type: 'income', category: 'Salary', date: '2024-01-15', notes: 'January salary' });
    expect(res.status).toBe(201);
    txId = res.body.data.id;
  });

  it('viewer cannot create a transaction', async () => {
    const res = await request(app)
      .post('/api/transactions')
      .set('Authorization', `Bearer ${viewerToken}`)
      .send({ amount: 100, type: 'expense', category: 'Food', date: '2024-01-10' });
    expect(res.status).toBe(403);
  });

  it('all roles can list transactions', async () => {
    const res = await request(app)
      .get('/api/transactions')
      .set('Authorization', `Bearer ${viewerToken}`);
    expect(res.status).toBe(200);
    expect(res.body.data).toHaveProperty('data');
  });

  it('analyst can update a transaction', async () => {
    const res = await request(app)
      .put(`/api/transactions/${txId}`)
      .set('Authorization', `Bearer ${analystToken}`)
      .send({ notes: 'Updated note' });
    expect(res.status).toBe(200);
  });

  it('only admin can delete a transaction', async () => {
    const noAccess = await request(app)
      .delete(`/api/transactions/${txId}`)
      .set('Authorization', `Bearer ${analystToken}`);
    expect(noAccess.status).toBe(403);

    const ok = await request(app)
      .delete(`/api/transactions/${txId}`)
      .set('Authorization', `Bearer ${adminToken}`);
    expect(ok.status).toBe(200);
  });

  it('returns 400 for invalid transaction data', async () => {
    const res = await request(app)
      .post('/api/transactions')
      .set('Authorization', `Bearer ${adminToken}`)
      .send({ amount: -100, type: 'invalid', category: '', date: 'bad-date' });
    expect(res.status).toBe(400);
  });
});

// ── Dashboard Tests ───────────────────────────────────────────────────────────
describe('Dashboard', () => {
  it('analyst can access summary', async () => {
    const res = await request(app).get('/api/dashboard/summary').set('Authorization', `Bearer ${analystToken}`);
    expect(res.status).toBe(200);
    expect(res.body.data).toHaveProperty('netBalance');
  });

  it('viewer cannot access dashboard', async () => {
    const res = await request(app).get('/api/dashboard/summary').set('Authorization', `Bearer ${viewerToken}`);
    expect(res.status).toBe(403);
  });
});

// ── User Management Tests ─────────────────────────────────────────────────────
describe('User Management', () => {
  it('admin can list users', async () => {
    const res = await request(app).get('/api/users').set('Authorization', `Bearer ${adminToken}`);
    expect(res.status).toBe(200);
  });

  it('non-admin cannot list users', async () => {
    const res = await request(app).get('/api/users').set('Authorization', `Bearer ${analystToken}`);
    expect(res.status).toBe(403);
  });
});
